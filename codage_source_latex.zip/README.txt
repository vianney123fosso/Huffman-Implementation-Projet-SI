Rapport « Codage de source » — version LaTeX (Overleaf)

Contenu
  main.tex      préambule, page de garde, sommaire, listes ; inclut body.tex
  body.tex      corps du rapport (chapitres 1 à 6, conclusion, références, annexe A)
  figures/      figures PNG et logo ENSPY

Compilation sur Overleaf
  1. Menu > New Project > Upload Project, puis choisir ce fichier .zip.
  2. Compilateur : pdfLaTeX (par défaut). Document principal : main.tex.
  3. Compiler deux fois (ou une fois, Overleaf relance automatiquement) pour que
     le sommaire, les listes et les renvois soient à jour.

Pour compléter la page de garde : les lignes « Présenté par », « Enseignant » et « Date »
sont laissées vides ; remplir dans main.tex, bloc \begin{titlepage}.
Les numéros de théorèmes, d'équations, d'algorithmes et d'extraits sont écrits à la main
dans le texte (comme dans la version Word) ; ceux des chapitres, sections et figures sont automatiques.
